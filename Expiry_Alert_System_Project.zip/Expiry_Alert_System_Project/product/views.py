from django.shortcuts import render, HttpResponse
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from pytz import timezone
from .models import Product, Category, Batch
from django.urls import reverse_lazy
from django.contrib.messages.views import SuccessMessageMixin
from django.utils import timezone
from django.contrib.auth import authenticate, login
from . forms import LoginForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.paginator import Paginator, EmptyPage,\
PageNotAnInteger


@login_required
def user_login(request):
    """ user login view """
    if request.methond == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user = authenticate(request,
                                username=cd['username'],
                                password=cd['password']
                            )
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return HttpResponse('Login sucessfully')
                else:
                    return HttpResponse('Disable')
            else:
                return HttpResponse('Invalid Account')
    else:
        form = LoginForm()
    return render(request, 'registration/login.html')


@login_required
def dashboard(request):
    # product = Product.objects.all()
    object_list = Product.objects.all()
    paginator = Paginator(object_list, 6) # 10 products in each page
    page = request.GET.get('page')
    try:
        products = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer deliver the first page
        products = paginator.page(1)
    except EmptyPage:
        # If page is out of range deliver last page of results
        products = paginator.page(paginator.num_pages)
    
    category = Category.objects.all()
    batch = Batch.objects.all()
    return render(request, 'product/dashboard.html', {
    # 'product':product,
                                                      'category':category,
                                                      'batch':batch,
                                                      'products':products,
                                                      'page':page,
                                                      'object_list':object_list})



def search(request):
    """ Fuction that cares about searching of a product  """
    q=request.GET['q']
    product = Product.objects.filter(name__icontains=q)
    data = Product.objects.filter(name__icontains=q).order_by('-name')
    return render(request, 'product/search.html', {'data':data,
                                                   'product':product})
    


class ProductCreate(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    model = Product
    fields = "__all__"
    template_name = "product/product_create.html"
    context_object_name = "product"
    success_url = reverse_lazy("dashboard")
    success_message = "Product Added successfully"

class ProductList(LoginRequiredMixin, ListView):
    queryset = Product.objects.filter(expiry__gte=timezone.now())
    paginate_by = 10
    template_name = "product/product_list.html"
    context_object_name = "product"

class ProductUpdate(LoginRequiredMixin, UpdateView):
    model = Product
    fields = "__all__"
    template_name = "product/product_update.html"
    context_object_name = "form"
    success_url = reverse_lazy("dashboard")
    success_message = "Product Updated successfully"
    
class ProductDelete(LoginRequiredMixin, SuccessMessageMixin, DeleteView):
    model = Product
    template_name = "product/product_delete.html"
    context_object_name = 'product'
    success_url = reverse_lazy('dashboard')
    success_message = "Product Deleted Successfully"
    
class ProductDetail(LoginRequiredMixin, SuccessMessageMixin, DetailView):
    model = Product
    template_name = "product/product_detail.html"
    context_object_name = "product"


class BatchCreate(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    model = Batch
    fields = '__all__'
    template_name = "product/batch_create.html"
    context_object_name = "form"
    success_url = reverse_lazy("dashboard")
    success_message = "Batch Created successfully"

class BatchList(LoginRequiredMixin, SuccessMessageMixin, ListView):
    model = Batch
    template_name = "product/batch_list.html"
    context_object_name = "batches" 
    
class CategoryCreate(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    model = Category
    fields = '__all__'
    template_name = "product/category_create.html"
    context_object_name = "form"
    success_url = reverse_lazy("dashboard")
    success_message = "Category created successfully"

class CategoryList(LoginRequiredMixin, SuccessMessageMixin, ListView):
    model = Category
    template_name = "product/category_list.html"
    context_object_name = "categories"
