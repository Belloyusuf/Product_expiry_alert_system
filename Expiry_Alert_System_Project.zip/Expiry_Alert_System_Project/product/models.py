# Product Model
from django.db import models



class Batch(models.Model):
    name = models.CharField(("Batch Name"), max_length=50)
    created = models.DateField(auto_now=True, auto_now_add=False)
    updated = models.DateField(auto_now=False, auto_now_add=True)
    
    def __str__(self):
        return self.name
    
    class Meta:
        ordering = ('name',)

class Category(models.Model):
    name = models.CharField(max_length=50)
    created = models.DateField(auto_now=True, auto_now_add=False)
    updated = models.DateField(auto_now=False, auto_now_add=True)
    
    
    def __str__(self):
        return self.name
    
    class Meta:
        ordering = ('name',)
    

class Product(models.Model):
    batch = models.ForeignKey(Batch, verbose_name=("Batch"), on_delete=models.CASCADE)
    category = models.ForeignKey(Category, verbose_name=("categories"), on_delete=models.CASCADE)
    name = models.CharField(("Product Name"), max_length=50)
    m_name = models.CharField(("Manufacture Name"), max_length=50)
    barcode = models.BigIntegerField(unique=True)
    quantity = models.IntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    m_date = models.DateField(("Manufacturing Date"), help_text="yyyy-mm-dd", null=True, blank=True)
    expiry = models.DateField(("Expiry Date"), help_text="yyyy-mm-dd")
    
    
    def __str__(self):
        return self.name

    class Meta:
        ordering = ('id',)

