from django import views
from django.urls import path
from product.views import ProductCreate, ProductDelete, ProductList, \
                          ProductUpdate, BatchCreate, CategoryCreate, ProductDetail, BatchList, CategoryList
from . import views
# from django.contrib.auth import views as auth_views


urlpatterns = [
    path('', views.dashboard, name="dashboard"),
    path('search/', views.search, name="search"),
    path('list/', ProductList.as_view(), name="product-list"),
    path('create/', ProductCreate.as_view(), name="product-create"),
    path('update/<int:pk>/', ProductUpdate.as_view(), name="product-update"),
    path('detail/<int:pk>/', ProductDetail.as_view(), name="product-detail"),
    path('delete/<int:pk>/', ProductDelete.as_view(), name="product-delete"),
    path('batch/', BatchCreate.as_view(), name="batch-create"),
    path('batch-list/', BatchList.as_view(), name="batch-list"),
    path('category/', CategoryCreate.as_view(), name="category-create"),
    path('category-list/', CategoryList.as_view(), name="category-list"),
    
    
]
