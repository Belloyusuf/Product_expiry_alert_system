from django import template
from product.models import Product, Category, Batch
from django.utils import timezone
from django.db.models import Sum

register = template.Library()

@register.simple_tag
def total_product():
   return Product.objects.all().count()


@register.simple_tag
def total_product_price():
   return Product.objects.all().aggregate(Sum('price'))['price__sum']

@register.simple_tag
def total_categories():
   return Category.objects.all().count()

@register.simple_tag
def total_batches():
   return Batch.objects.all().count()

@register.simple_tag
def total_exp_price():
   return Product.objects.filter(expiry__gte=timezone.now()).aggregate(Sum('price'))["price__sum"]


@register.simple_tag
def total_expiry():
   return Product.objects.filter(expiry__gte=timezone.now()).count()
