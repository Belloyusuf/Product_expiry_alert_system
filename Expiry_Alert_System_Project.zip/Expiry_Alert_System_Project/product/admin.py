from django.contrib import admin
from .models import Product, Batch, Category

# Register your models here.

admin.site.register([Batch, Category])
admin.site.site_header = "Expiry Alert System"

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ["batch", "category", "name", 
                    "barcode", "quantity", "price", "m_date", "expiry"]
    